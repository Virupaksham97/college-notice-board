
<?php

$host = "sql310.infinityfree.com";
$dbname = "if0_43340892_college_notice";
$dbuser = "if0_43340892";
$dbpass = "YOUR_MYSQL_PASSWORD";

try {
    $pdo = new PDO(
        "mysql:host=$host;port=3306;dbname=$dbname;charset=utf8mb4",
        $dbuser,
        $dbpass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );

} catch (PDOException $e) {
    exit("Database connection failed. Please check your hosting credentials.");
}

?>
